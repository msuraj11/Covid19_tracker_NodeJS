// 
const express = require('express');
const fetch = require('node-fetch');
const app = express();

//Access control for FE
app.use(function (req, res, next) {
  res.setHeader('Access-Control-Allow-Origin', 'http://localhost:3000');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');
  res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');
  next();
});

// @route   GET /covid19_summary
// @desc    fetch summarized data of covid19
// @access  Public
app.get('/covid19_summary', function (req, res) {
    fetch('https://api.covid19api.com/summary')
  .then(response => response.json())
  .then(json => res.send(json));
});

// @route   GET /covid19_total/:country_name
// @desc    fetches country specific data of covid19
// @access  Public
app.get('/covid19_total/:country_name', function (req, res) {
  fetch(`https://api.covid19api.com/total/country/${req.params.country_name}`)
.then(response => response.json())
.then(json => res.send(json));
});

//Making Node server run on server 8081
const server = app.listen(8081, function () {
   const host = server.address().address;
   const port = server.address().port; 
   console.log("Listening at http://%s:%s", host, port)
});